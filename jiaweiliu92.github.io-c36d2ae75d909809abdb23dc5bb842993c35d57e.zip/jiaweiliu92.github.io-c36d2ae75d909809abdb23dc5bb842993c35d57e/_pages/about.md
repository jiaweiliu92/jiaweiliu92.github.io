---
permalink: /
title: ""
excerpt: ""
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

{% if site.google_scholar_stats_use_cdn %}
{% assign gsDataBaseUrl = "https://cdn.jsdelivr.net/gh/" | append: site.repository | append: "@" %}
{% else %}
{% assign gsDataBaseUrl = "https://raw.githubusercontent.com/" | append: site.repository | append: "/" %}
{% endif %}
{% assign url = gsDataBaseUrl | append: "google-scholar-stats/gs_data_shieldsio.json" %}

<span class='anchor' id='about-me'></span>

<div class="academic-card section-about-me" markdown="1">

<h1 id="about-title">About Me</h1>

Hi! I’m Jiawei Liu (刘嘉威), an Associate Professor in the Department of Automation at the University of Science and Technology of China (中国科学技术大学). I work with [Prof. Zheng-Jun Zha](https://auto.ustc.edu.cn/2021/0510/c25976a484878/page.htm) at [the Lab for Multimodal Embodied Intelligence (多模态具身智能实验室)](https://ustc-milab.github.io/). My research focuses on human-centric visual understanding, fake media content analysis, multimodal large language models, and embodied AI. I have published more than 70 papers in leading AI journals and conferences. <a href='https://scholar.google.com/citations?user=sR7Sf2YAAAAJ'><img src="https://img.shields.io/endpoint?url=https%3A%2F%2Fcdn.jsdelivr.net%2Fgh%2Fjiaweiliu92%2Fjiaweiliu92.github.io@google-scholar-stats%2Fgs_data_shieldsio.json&logo=Google%20Scholar&labelColor=f6f6f6&color=9cf&style=flat&label=citations"></a>


I received my B.S. degree from Hefei University of Technology (HFUT) in 2013 and my Ph.D. degree from the University of Science and Technology of China (USTC) in 2019. During my Ph.D., I was a research intern at [Microsoft Research Asia (MSRA)](https://www.microsoft.com/en-us/research/lab/microsoft-research-asia-zh-cn/?lang=zh-cn) <img src="./images/microsoft.png" style="width: 4.5em;"> under the supervision of [Prof. Tao Mei](https://taomei.me/) from October 2016 to January 2017. From September 2025 to August 2026, I was a visiting scholar at the National University of Singapore (NUS) <img src="./images/nus.png" style="width: 2.7em;">, under the supervision of [Prof. Shuicheng Yan](https://www.lv-lab.org/).


<div class="recruitment-note" markdown="1">

I welcome applications from motivated graduate students interested in computer vision, multimedia analysis, and embodied AI. Students with backgrounds in mathematics, machine learning, or programming are encouraged to email me a brief introduction and CV. I also welcome opportunities for **academic collaboration**. Please contact me at [jwliu6@ustc.edu.cn](mailto:jwliu6@ustc.edu.cn).


🌟 欢迎热爱科研、愿意主动投入的本科生加入课题组，参与科研实习、大创或暑研。研究方向包括以人为中心的视觉理解、多模态大模型和具身智能。数学、物理、计算机等相关专业的同学均可通过邮件联系，并附上个人简历；有意继续深造的同学也欢迎交流。

</div>

</div>

<span class='anchor' id='news'></span>

<div class="academic-card section-news" markdown="1">

<div class="news-heading-block">
<h1 id="-news">News</h1>
<div id="news-year-tabs" class="news-year-tabs" role="group" aria-label="Filter news by year"></div>
</div>

<div class="academic-group" markdown="1">

<div id="news-by-year" class="news-by-year" aria-live="polite" markdown="1">
- \[*2026.11*\]: &nbsp;🎉🎉 One paper on the AI-generated video detection is accepted by <span style="color:#1a73e8; font-weight:500;">JICN</span> 2026.
- \[*2026.10*\]: &nbsp;🎉🎉 One paper on the landscape of medical agents is accepted by <span style="color:#1a73e8; font-weight:500;">TMLR</span> 2026.
- \[*2026.09*\]: &nbsp;🎉🎉 One paper on tool-augmented scientific reasoning is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2026.  
- \[*2026.09*\]: &nbsp;🎉🎉 One paper on open-vocabulary HOI detection is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2026.
- \[*2026.09*\]: &nbsp;🎉🎉 One paper on point cloud segmentation is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2026.
- \[*2026.09*\]: &nbsp;🎉🎉 One paper on thinking with images is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2026.
- \[*2026.09*\]: &nbsp;🎉🎉 One paper on image forgery detection and localization is accepted by <span style="color:#1a73e8; font-weight:500;">IEEE TIP</span> 2026.
- \[*2026.08*\]: &nbsp;🎉🎉 One paper on open-ended agent RL is accepted by <span style="color:#1a73e8; font-weight:500;">EMNLP Findings</span> 2026.
- \[*2026.07*\]: &nbsp;🎉🎉 One paper on wu dialect vowel recognition is accepted by <span style="color:#1a73e8; font-weight:500;">CICAI</span> 2026.
- \[*2026.07*\]: &nbsp;🎉🎉 One paper on stealthy backdoor is accepted by <span style="color:#1a73e8; font-weight:500;">IEEE TPAMI</span> 2026.
- \[*2026.06*\]: &nbsp;🎉🎉 One paper on agentic tool use is accepted by <span style="color:#1a73e8; font-weight:500;">ECCV</span> 2026.
- \[*2026.06*\]: &nbsp;🎉🎉 One paper on visible-infrared person identification is accepted by <span style="color:#1a73e8; font-weight:500;">IEEE TIFS</span> 2026.
- \[*2026.06*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Jingyi Xie (谢璟毅)</span> on earning his Ph.D. degree! 
- \[*2026.06*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Changrong Hu (胡长荣)</span> on earning her Master’s degree!    
- \[*2026.05*\]: &nbsp;🎉🎉 One paper on open-ended agents is accepted by <span style="color:#1a73e8; font-weight:500;">ICML</span> 2026.
- \[*2026.04*\]: &nbsp;🎉🎉 One paper on automatic rigging is accepted by <span style="color:#1a73e8; font-weight:500;">ICIC</span> 2026. <span class="badge-highlight">Oral</span>
- \[*2026.03*\]: &nbsp;🏆🏆 Won the champion of the 2nd multimodal deception detection competition @<span style="color:#1a73e8; font-weight:500;">CVPR</span> 2026.
- \[*2026.03*\]: &nbsp;🏛️🏛️ Promoted to Associate Professor (tenured) at <span style="color:#198754; font-weight:500;">USTC</span>.
- \[*2026.02*\]: &nbsp;🎉🎉 One paper on open-vocabulary HOI detection is accepted by <span style="color:#1a73e8; font-weight:500;">CVPR</span> 2026. <span class="badge-highlight">Highlight</span>
- \[*2026.01*\]: &nbsp;🎉🎉 One paper on active prompt learning is accepted by <span style="color:#1a73e8; font-weight:500;">ICLR</span> 2026. 
- \[*2026.01*\]: &nbsp;🎉🎉 One paper on multimodal fact-checking is accepted by <span style="color:#1a73e8; font-weight:500;">WWW</span> 2026. <span class="badge-highlight">Oral</span> 
- \[*2025.12*\]: &nbsp;🎉🎉 One paper on class incremental learning is accepted by <span style="color:#1a73e8; font-weight:500;">CVM</span> 2026. 
- \[*2025.11*\]: &nbsp;🎉🎉 One paper on zero-shot HOI detection is accepted by <span style="color:#1a73e8; font-weight:500;">IJCV</span> 2025. 
- \[*2025.11*\]: &nbsp;🎉🎉 One paper on occluded person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">JICN</span> 2025. 
- \[*2025.10*\]: &nbsp;🎉🎉 One paper on active prompt learning is accepted by <span style="color:#1a73e8; font-weight:500;">IJCV</span> 2025. 
- \[*2025.09*\]: &nbsp;🎉🎉 One paper on explainable video misinformation detection is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2025. 
- \[*2025.09*\]: &nbsp;🎉🎉 One paper on multimodal knowledge editing is accepted by <span style="color:#1a73e8; font-weight:500;">NeurIPS</span> 2025. 
- \[*2025.09*\]: &nbsp;🎉🎉 One paper on fake news detection is accepted by <span style="color:#1a73e8; font-weight:500;">IEEE TKDE</span> 2025.
- \[*2025.09*\]: &nbsp;✈️✈️ Started as a visiting scholar at the <span style="color:#198754; font-weight:500;">National University of Singapore</span>.
- \[*2025.07*\]: &nbsp;🎉🎉 One paper on person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">ACM MM</span> 2025. 
- \[*2025.06*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Wei Wu (吴蔚)</span> on earning her Ph.D. degree! 
- \[*2025.06*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Hao Tong (童浩)</span> on earning his Master’s degree!  
- \[*2025.04*\]: &nbsp;🎉🎉 One paper on image forgery detection and localization is accepted by <span style="color:#1a73e8; font-weight:500;">IJCAI</span> 2025. 
- \[*2025.02*\]: &nbsp;🎉🎉 One paper on test-time adaptation is accepted by <span style="color:#1a73e8; font-weight:500;">CVPR</span> 2025. 
- \[*2025.02*\]: &nbsp;🎉🎉 One paper on comprehensive image captioning is accepted by <span style="color:#1a73e8; font-weight:500;">CVPR</span> 2025. 
- \[*2025.01*\]: &nbsp;🎉🎉 One paper on person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">IEEE TIFS</span> 2025.
- \[*2024.12*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Bingyu Hu (胡冰玉)</span> on earning her Ph.D. degree! 
- \[*2024.12*\]: &nbsp;🎉🎉 One paper on person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">CVM</span> 2025.
- \[*2024.12*\]: &nbsp;🎉🎉 One paper on human-object interaction is accepted by <span style="color:#1a73e8; font-weight:500;">AAAI</span> 2025. 
- \[*2024.10*\]: &nbsp;🎉🎉 One paper on person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">ACM TOMM</span> 2024. 
- \[*2024.08*\]: &nbsp;🎉🎉 One paper on image forgery localization is accepted by <span style="color:#1a73e8; font-weight:500;">ECCV</span> 2024.
- \[*2024.06*\]: &nbsp;🎓🎓 Congratulations to <span style="color:#d35400; font-weight:500;">Wenjun Gan (甘文君)</span> on earning her Master’s degree!  
- \[*2024.04*\]: &nbsp;🎉🎉 One paper on person re-identification is accepted by <span style="color:#1a73e8; font-weight:500;">ICME</span> 2024.
</div>
</div>

<script>
  (function () {
    'use strict';

    var list = document.getElementById('news-by-year');
    var controls = document.getElementById('news-year-tabs');
    if (!list || !controls) return;

    var items = Array.prototype.slice.call(list.querySelectorAll('li'));
    var years = [];
    var counts = {};

    items.forEach(function (item) {
      var date = item.querySelector('em');
      var match = date && date.textContent.trim().match(/^(\d{4})/);
      if (!match) return;

      item.setAttribute('data-news-year', match[1]);
      counts[match[1]] = (counts[match[1]] || 0) + 1;
      if (years.indexOf(match[1]) === -1) years.push(match[1]);
    });

    years.sort(function (a, b) { return Number(b) - Number(a); });
    if (!years.length) return;

    function selectYear(year, selectedButton) {
      items.forEach(function (item) {
        item.hidden = item.getAttribute('data-news-year') !== year;
      });

      Array.prototype.forEach.call(controls.querySelectorAll('button'), function (button) {
        var selected = button === selectedButton;
        button.setAttribute('aria-pressed', selected ? 'true' : 'false');
        button.classList.toggle('is-active', selected);
      });
    }

    years.forEach(function (year, index) {
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'news-year-tab';
      button.setAttribute('aria-label', year + ': ' + counts[year] + ' news items');
      var yearLabel = document.createElement('span');
      yearLabel.textContent = year;
      yearLabel.setAttribute('aria-hidden', 'true');
      var countLabel = document.createElement('small');
      countLabel.className = 'news-year-count';
      countLabel.textContent = counts[year];
      countLabel.setAttribute('aria-hidden', 'true');
      button.appendChild(yearLabel);
      button.appendChild(countLabel);
      button.setAttribute('aria-pressed', index === 0 ? 'true' : 'false');
      button.addEventListener('click', function () {
        selectYear(year, button);
      });
      controls.appendChild(button);
    });

    var firstButton = controls.querySelector('button');
    if (firstButton) {
      firstButton.classList.add('is-active');
      selectYear(years[0], firstButton);
    }
  })();
</script>

</div>

<span class='anchor' id='publications'></span>

<div class="academic-card section-publications" markdown="1">

<div class="news-heading-block publications-heading-block">
<h1 id="-publications">Publications</h1>
<div id="publications-year-tabs" class="news-year-tabs" role="group" aria-label="Filter publications by year"></div>
</div>

<div class="academic-group publication-year-group" data-publication-year="2026" markdown="1">
- ``NeurIPS 2026`` [Learning Where to Look: Observation Policy Optimization for Thinking with Images](https://arxiv.org/pdf/2611.04943) <br> Junfeng Wang, **Jiawei Liu**, Yongchao Xu, Tao Jiang, Jiangbo Ai, Jin Zhang, Chong Wang, Qixing Zhang [![](https://img.shields.io/github/stars/Yann0122/Observation-Policy-Optimization?style=social&label=Code+Stars)](https://github.com/Yann0122/Observation-Policy-Optimization)
- ``IEEE TIFS 2026`` [Frequency-Guided Multi-Perspective Prompt Learning for Visible-Infrared Person Re-identification](https://ieeexplore.ieee.org/document/11560981) <br> **Jiawei Liu**, Yong Wu, Yufei Zheng, Hao Tong, Guozhi Zhao, Zheng-Jun Zha
- ``CVPR 2026`` [Learning to Diversify and Focus: A Reinforcement Framework for Open-Vocabulary HOI Detection](https://openaccess.thecvf.com/content/CVPR2026/papers/Xu_Learning_to_Diversify_and_Focus_A_Reinforcement_Framework_for_Open-Vocabulary_CVPR_2026_paper.pdf) <br> Yongchao Xu, **Jiawei Liu**, Junfeng Wang, Sen Tao, Na Jiang, Zheng-Jun Zha
- ``ICIC 2026`` [AnySkel: Automatic Rigging for any Skeletal Template](https://link.springer.com/chapter/10.1007/978-981-92-3397-7_49) <br> Changrong Hu, Na Jiang, **Jiawei Liu**
- ``IEEE TPAMI 2026`` [Threat in Frequency: Unveiling Hidden Attack Surfaces by Exploiting Stealthy Backdoors on Diffusion Models](https://ieeexplore.ieee.org/document/11602676) <br> Jingyi Xie, **Jiawei Liu**, Fanrui Zhang, Dong Li, Xueyang Fu, Zheng-Jun Zha
- ``JICN 2026`` [Semantic-Aware Contrasting with Explicitly Disentangled Representations for AI-Generated Video Detection](https://www.ffspub.com/index.php/jicn/article/view/159) <br> Jiaquan Yu, Jingyi Xie, Zeyu Zhang, Yunhang Qian, Xiaobin Hu, **Jiawei Liu**
- ``CICAI 2026`` [SA-AEF: Source-Aware Acoustic Enhanced Fusion for Cross-Regional Wu Dialect Vowel Recognition](./files/papers/Source-Aware Acoustic Enhanced Fusion for Cross-Regional Wu Dialect Vowel Recognition.pdf) <br> Xinyang Liu, Huahan Wang, Ning Nie, Hui Zheng, **Jiawei Liu**, Tong Xu, Xinming Zhang, Shuping He
- ``CVPRW 2026`` [PRISM: Prior-Informed Semantic Multimodal Fusion for Audio-Visual Deception Detection](https://openaccess.thecvf.com/content/CVPR2026W/SVC/papers/Yu_PRISM_Prior-Informed_Semantic_Multimodal_Fusion_for_Audio-Visual_Deception_Detection_CVPRW_2026_paper.pdf) <br> Jiaquan Yu, Yetao Fan, Yuanfang Shi, Rongtian Wang, Hui Zheng, Shuping He, **Jiawei Liu**, Zheng-Jun Zha
- ``WWW 2026`` [Navigating Truth in Multimodal Fact-checking via Retrieval- and Reasoning-Enhanced Large Language Models](https://dl.acm.org/doi/pdf/10.1145/3774904.3792706) <br> Fanrui Zhang, Qiang Zhang, Jianwen Sun, Chuanhao Li, Jiaxin Ai, Yukang Feng, Zizhen Li, Kaipeng Zhang, **Jiawei Liu**, Zheng-Jun Zha
- `TMLR 2026` [The Landscape of Medical Agents: A Survey](https://www.techrxiv.org/doi/pdf/10.36227/techrxiv.176581395.56964766/v4?redirectToLatest=false) <br> Xiaobin Hu, Yunhang Qian, Jiaquan Yu, jingjing liu, Xiaozhong Ji, Peng TANG, Chengming Xu, **Jiawei Liu**, Xinlei Yu, Guibin Zhang, Xiaomin Yu, Yue Liao, Jiazhen Pan, Zhe Xu, Bailiang Jian, Kai WU, Jiangning Zhang, Shanghua Gao, Yueming Jin, Zuxuan Wu, Yanwei Fu, Hongwei Bran Li, Bjoern Menze, Yu-Gang Jiang, Daniel Rueckert, Shuicheng Yan \| [**Project**](https://nus-project.github.io/Landmark-of-medical-agent/)
- `IEEE TIP 2026` [ForgeryGPT: A Multimodal LLM for Interpretable Image Forgery Detection and Localization](https://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=11709464) <br> Fanrui Zhang, **Jiawei Liu**, Jiaying Zhu, Esther Sun, Qiang Zhang, Zheng-Jun Zha
- `EMNLP-F 2026` [ArenaFlow: From Trajectory Ranking to Hierarchical Credit Propagation for Open-Ended Agent RL](https://aclanthology.org/2026.findings-emnlp.2341.pdf) <br> Qiang Zhang, Ruixue Ding, Fanrui Zhang, Xi Chen, Boli Chen, Shihang Wang, Yinfeng Huang, Yi Zheng, Pengjun Xie, Kaipeng Zhang, **Jiawei Liu**, Zheng-Jun Zha
- `ECCV 2026` [Code-in-the-Loop Forensics: Agentic Tool Use for Image Forgery Detection](https://media.eventhosts.cc/Conferences/ECCV2026/pdfs/13341.pdf) <br> Fanrui Zhang, Qiang Zhang, Sizhuo Zhou, Jianwen Sun, Chuanhao Li, Jiaxin Ai, Yukang Feng, Yujie Zhang, Wenjie Li, Zizhen Li, Yifan Chang, **Jiawei Liu**, Kaipeng Zhang [![](https://img.shields.io/github/stars/zfr00/ForenAgent?style=social&label=Code+Stars)](https://github.com/zfr00/ForenAgent)
- ``ICML 2026`` [ArenaRL: Scaling RL for Open-Ended Agents via Tournament-based Relative Ranking](https://icml.cc/virtual/2026/poster/66670) <br> Qiang Zhang, Boli Chen, Fanrui Zhang, Ruixue Ding, Shihang Wang, Qiuchen Wang, Yinfeng Huang, Haonan Zhang, Rongxiang Zhu, Xin Li, Houquan Zhou, Pengjun Xie, Kaipeng Zhang, Jingren Zhou, **Jiawei Liu** \| [**Project**](https://github.com/Alibaba-NLP/qqr/) [![](https://img.shields.io/github/stars/Alibaba-NLP/qqr?style=social&label=Code+Stars)](https://github.com/Alibaba-NLP/qqr)
- ``CVM 2026`` [Mining the Potential of Rehearsal Mechanism for VLM-based Class Incremental Learning](https://iccvm.org/2026/files/papers/9.pdf) <br> Sen Tao, **Jiawei Liu**, Yongchao Xu, Guangxi Wan, and Peng Zeng
- ``ICLR 2026`` [PSP: Prompt-Guided Self-Training Sampling Policy for Active Prompt Learning](https://openreview.net/pdf?id=7D7VLU9227) <br> Sen Tao, Kaiduo Feng, **Jiawei Liu**, Peng Zeng, Yongchao Xu, Yufei Zheng, Zheng-Jun Zha
</div>

<div class="academic-group publication-year-group" data-publication-year="2025" markdown="1">
- ``IJCV 2025`` [Mamba-Driven Comprehensive Context Learning for Zero-Shot HOI Detection](https://link.springer.com/article/10.1007/s11263-025-02616-y) <br> **Jiawei Liu**, Yongchao Xu, Sen Tao, Yuexuan Qi, Zheng-Jun Zha
- ``ACM MM 2025`` [Dual Uncertainty-Guided Feature Alignment Learning for Text-Based Person Retrieval](https://dl.acm.org/doi/abs/10.1145/3746027.3755063) <br> Yufei Zheng, **Jiawei Liu**, Bingyu Hu, Zikun Wei, Yong Wu, Zheng-Jun Zha
- ``JICN 2025`` [Occlusion-Guided Feature Purification Learning via Reinforced Knowledge Distillation for Occluded Person Re-Identification](https://www.ffspub.com/index.php/jicn/article/view/31) <br> Yufei Zheng, Yong Wu, **Jiawei Liu**, Wenjun Wang, Wenjun Gan
- ``CVM 2025`` [Multi-granularity and Multi-modal Prompt Learning for Person Re-Identification](https://link.springer.com/chapter/10.1007/978-981-96-5815-2_10) <br> Hao Tong, **Jiawei Liu**, Yong Wu, Guozhi Zhao, Fanrui Zhang, Zheng-Jun Zha
- ``AAAI 2025`` [HOIMamba: Efficient Mamba-based Disentangled Progressive Learning for HOI Detection](https://ojs.aaai.org/index.php/AAAI/article/view/32972) <br> Yongchao Xu, **Jiawei Liu**, Sen Tao, Qiang Zhang, Zheng-Jun Zha
- ``IEEE TIFS 2025`` [Advancing Visible-Infrared Person Re-Identification: Synergizing Visual-Textual Reasoning and Cross-Modal Feature Alignment](https://ieeexplore.ieee.org/document/10879282) <br> Yuxuan Qiu, Liyang Wang, Wei Song, **Jiawei Liu**, Zhiping Shi, Na Jiang
- ``NeurIPS 2025`` [Fact-R1: Towards Explainable Video Misinformation Detection with Deep Reasoning](https://openreview.net/pdf?id=EeyvDitalf) <br> Fanrui Zhang, Dian Li, Qiang Zhang, Jun Chen, Gang Liu, Junxiong Lin, Jiahong Yan, **Jiawei Liu**, Zheng-Jun Zha [![](https://img.shields.io/github/stars/zfr00/fact-r1?style=social&label=Code+Stars)](https://github.com/zfr00/fact-r1)
- ``IEEE TKDE 2025`` [Toward Effective and Transferable Detection for Multi-modal Fake News in the Social Media Stream](https://ieeexplore.ieee.org/document/11159538) <br> Jingyi Xie, **Jiawei Liu**, Zheng-Jun Zha
- ``IJCAI 2025`` [Learnable Frequency Decomposition for Image Forgery Detection and Localization](https://www.ijcai.org/proceedings/2025/0152.pdf) <br> Dong Li, Jiaying Zhu, Yidi Liu, Xin Lu, Xueyang Fu, **Jiawei Liu**, Aiping Liu, Zheng-Jun Zha
- ``IJCV 2025`` [Boosting Active Prompt Learning via Discriminative Self-Training Dual-Curriculum Learning](https://link.springer.com/article/10.1007/s11263-025-02641-x) <br> Sen Tao, **Jiawei Liu**, Peng Zeng, Yongchao Xu, Bingyu Hu, Zheng-Jun Zha
- `NeurIPS 2025` [Reliable Lifelong Multimodal Editing: Conflict-Aware Retrieval Meets Multi-Level Guidance](https://openreview.net/pdf?id=hdJXzKZjY9) <br> Qiang Zhang, Fanrui Zhang, **Jiawei Liu**, Ming Hu, Junjun He, Zheng-Jun Zha
- `CVPR 2025` [Hierarchical Knowledge Prompt Tuning for Multi-task Test-Time Adaptation](https://openaccess.thecvf.com/content/CVPR2025/html/Zhang_Hierarchical_Knowledge_Prompt_Tuning_for_Multi-task_Test-Time_Adaptation_CVPR_2025_paper.html) <br> Qiang Zhang, Mengsheng Zhao, **Jiawei Liu**, Fanrui Zhang, Yongchao Xu, Zheng-Jun Zha
- ``CVPR 2025`` [Benchmarking Large Vision-Language Models via Directed Scene Graph](https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=11093753) <br> Fan Lu, Wei Wu, Kecheng Zheng, Shuailei Ma, Biao Gong, **Jiawei Liu**, Wei Zhai, Cao Yang, Yujun Shen, Zheng-Jun Zha \| [**Project**](https://github.com/LuFan31/CompreCap/) [![](https://img.shields.io/github/stars/LuFan31/CompreCap?style=social&label=Code+Stars)](https://github.com/LuFan31/CompreCap)
</div>

<div class="academic-group publication-year-group" data-publication-year="2024" markdown="1">
- ``ACM TOMM 2024`` [Noise-Resistance Learning via Multi-Granularity Consistency for Unsupervised Domain Adaptive Person Re-Identification](https://dl.acm.org/doi/10.1145/3702328) <br> Yangchun Zhu, Yufei Zheng, **Jiawei Liu**, Yao Li, Zheng-Jun Zha
- ``ICME 2024`` [Joint Visual-Textual Reasoning and Visible-Infrared Modality Alignment for Person Re-Identification](https://ieeexplore.ieee.org/document/10688362) <br> Na Jiang, Yuxuan Qiu, Wei Song, **Jiawei Liu**, Zhiping Shi, Liyang Wang
- ``IJCV 2024`` [Exert Diversity and Mitigate Bias: Domain Generalizable Person Re-identification with a Comprehensive Benchmark](https://link.springer.com/article/10.1007/s11263-024-02124-5) <br> Bingyu Hu, **Jiawei Liu**, Yufei Zheng, Kecheng Zheng, Zheng-Jun Zha
- `MMM 2024` [Cross-Modal Semantic Alignment Learning for Text-Based Person Search](https://link.springer.com/chapter/10.1007/978-3-031-53305-1_16) <br> Wenjun Gan, **Jiawei Liu**, Yangchun Zhu, Yong Wu, Guozhi Zhao, Zheng-Jun Zha
- ``ECCV 2024`` [Noise-assisted Prompt Learning for Image Forgery Detection and Localization](https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/01688.pdf) <br> Dong Li, Jiaying Zhu, Xueyang Fu, Xun Guo, Yidi Liu, Gang Yang, **Jiawei Liu**, Zheng-Jun Zha
- ``IJCAI 2024`` [Natural Language-centered Inference Network for Multi-modal Fake News Detection](https://www.ijcai.org/proceedings/2024/281) <br> Qiang Zhang, **Jiawei Liu**, Fanrui Zhang, Jingyi Xie, Zheng-Jun Zha [![](https://img.shields.io/github/stars/juices6/NLIN?style=social&label=Code+Stars)](https://github.com//juices6/NLIN)
- ``WWW 2024`` [ESCNet: Entity-enhanced and Stance Checking Network for Multi-modal Fact-Checking](https://dl.acm.org/doi/abs/10.1145/3589334.3645455) <br> Fanrui Zhang, **Jiawei Liu**, Jingyi Xie, Qiang Zhang, Yongchao Xu, Zheng-Jun Zha [![](https://img.shields.io/github/stars/zfr00/ESCNet?style=social&label=Code+Stars)](https://github.com//zfr00/ESCNet)
- `ARXIV 2024` [TagAlign: Improving Vision-Language Alignment with Multi-Tag Classification](https://arxiv.org/abs/2312.14149) <br> Qinying Liu, Wei Wu, Kecheng Zheng, Zhan Tong, **Jiawei Liu**, Yu Liu, Wei Chen, Zilei Wang, Yujun Shen \| [**Project**](https://qinying-liu.github.io/Tag-Align/) [![](https://img.shields.io/github/stars/Qinying-Liu/TagAlign?style=social&label=Code+Stars)](https://github.com/Qinying-Liu/TagAlign)
</div>

<div class="academic-group publication-year-group" data-publication-year="2023" markdown="1">
- ``IEEE TMM 2023`` [Unleashing Knowledge Potential of Source Hypothesis for Source-Free Domain Adaptation](https://ieeexplore.ieee.org/abstract/document/10319072) <br> Bingyu Hu, **Jiawei Liu**, Kecheng Zheng, Zheng-Jun Zha
- ``PAIN 2023`` [Deep Learning–guided Postoperative Pain Assessment in Children](https://journals.lww.com/pain/fulltext/2023/09000/deep_learning_guided_postoperative_pain_assessment.16.aspx) <br> Jihong Fang, Wei Wu, **Jiawei Liu**, Sicheng Zhang
- ``IEEE TIFS 2023`` [Adaptive Texture and Spectrum Clue Mining for Generalizable Face Forgery Detection](https://ieeexplore.ieee.org/abstract/document/10364845) <br> **Jiawei Liu**, Jingyi Xie, Yang Wang, Zheng-Jun Zha
- ``ACM MM 2023`` [Hierarchical Semantic Enhancement Network for Multimodal Fake News Detection](https://dl.acm.org/doi/abs/10.1145/3581783.3612423) <br> Qiang Zhang, **Jiawei Liu**, Fanrui Zhang, Jingyi Xie, Zheng-Jun Zha
- ``ACM MM 2023`` [ECENet: Explainable and Context-Enhanced Network for Multi-modal Fact verification](https://dl.acm.org/doi/abs/10.1145/3581783.3612183) <br> Fanrui Zhang, **Jiawei Liu**, Qiang Zhang, Esther Sun, Jingyi Xie, Zheng-Jun Zha
- ``ARXIV 2023`` [Knowledge-enhanced Hierarchical Information Correlation Learning for Multi-modal Rumor Detection](https://arxiv.org/abs/2306.15946) <br> **Jiawei Liu**, Jingyi Xie, Fanrui Zhang, Qiang Zhang, Zheng-Jun Zha
- `De-Factify2 2023` [Unimodal Feature-Enhanced and Cross-Modal Correlation Learning for Multi-Modal Fact Verification](https://ceur-ws.org/Vol-3555/paper16.pdf) <br> Fanrui Zhang, Qiang Zhang, **Jiawei Liu**, Sun Esther
- `CVPR 2023` [Edge-Aware Regional Message Passing Controller for Image Forgery Localization](https://openaccess.thecvf.com/content/CVPR2023/html/Li_Edge-Aware_Regional_Message_Passing_Controller_for_Image_Forgery_Localization_CVPR_2023_paper.html) <br> Dong Li, Jiaying Zhu, Menglu Wang, **Jiawei Liu**, Xueyang Fu, Zheng-Jun Zha
- ``ICCV 2023`` [Regularized Mask Tuning: Uncovering Hidden Knowledge in Pre-trained Vision-Language Models](https://openaccess.thecvf.com/content/ICCV2023/papers/Zheng_Regularized_Mask_Tuning_Uncovering_Hidden_Knowledge_in_Pre-Trained_Vision-Language_Models_ICCV_2023_paper.pdf) <br> Kecheng Zheng, Wei Wu, Ruili Feng, Kai Zhu, **Jiawei Liu**, Deli Zhao, Zheng-Jun Zha, Wei Chen, Yujun Shen \| [**Project**](https://wuw2019.github.io/R-AMT/) [![](https://img.shields.io/github/stars/wuw2019/R-AMT?style=social&label=Code+Stars)](https://github.com/wuw2019/R-AMT)
</div>

<div class="academic-group publication-year-group" data-publication-year="2022" markdown="1">
- ``AAAI 2022`` [Debiased Batch Normalization via Gaussian Process for Generalizable Person Re-identification](https://ojs.aaai.org/index.php/AAAI/article/view/20065) <br> **Jiawei Liu**, Zhipeng Huang, Liang Li, Kecheng Zheng, Zheng-Jun Zha
- ``AAAI 2022`` [Modality-Adaptive Mixup and Invariant Decomposition for RGB-Infrared Person Re-identification](https://ojs.aaai.org/index.php/AAAI/article/view/19987) <br> Zhipeng Huang, **Jiawei Liu**, Liang Li, Kecheng Zheng, Zheng-Jun Zha
- ``CVPR 2022`` [Temporal Complementarity-Guided Reinforcement Learning for Image-to-Video Person Re-Identification](https://openaccess.thecvf.com/content/CVPR2022/papers/Wu_Temporal_Complementarity-Guided_Reinforcement_Learning_for_Image-to-Video_Person_Re-Identification_CVPR_2022_paper.pdf) <br> Wei Wu, **Jiawei Liu**, Kecheng Zheng, Qibin Sun, Zheng-Jun Zha
- `ACM MM 2022` [JPEG Compression-aware Image Forgery Localization](https://dl.acm.org/doi/abs/10.1145/3503161.3547749) <br> Menglu Wang, Xueyang Fu, **Jiawei Liu**, Zheng-Jun Zha
- `ARXIV 2022` [Label Noise-Resistant Mean Teaching for Weakly Supervised Fake News Detection](https://arxiv.org/abs/2206.12260) <br> Jingyi Xie, **Jiawei Liu**, Zheng-Jun Zha
</div>

<div class="academic-group publication-year-group" data-publication-year="2021" markdown="1">
- ``ARXIV 2021`` [Calibrated Feature Decomposition for Generalizable Person Re-Identification](https://arxiv.org/pdf/2111.13945) <br> Kecheng Zheng, **Jiawei Liu**, Wei Wu, Liang Li, Zheng-Jun Zha [![](https://img.shields.io/github/stars/zkcys001/CFD?style=social&label=Code+Stars)](https://github.com//zkcys001/CFD)
- `ACM MM 2021` [Cluster and Scatter: A Multi-grained Active Semi-supervised Learning Framework for Scalable Person Re-identification](https://dl.acm.org/doi/abs/10.1145/3474085.3475435) <br> Bingyu Hu, Zheng-Jun Zha, **Jiawei Liu**, Xierong Zhu, Hongtao Xie
- ``ACM MM 2021`` [Pose-Guided Feature Learning with Knowledge Distillation for Occluded Person Re-Identification](https://dl.acm.org/doi/abs/10.1145/3474085.3475610) <br> Kecheng Zheng, Cuiling Lan, Wenjun Zeng, **Jiawei Liu**, Zhizheng Zhang, Zheng-Jun Zha
- ``ICME 2021`` [Adversarial Disentanglement and Correlation Network for Rgb-Infrared Person Re-Identification](https://ieeexplore.ieee.org/abstract/document/9428376) <br> Bingyu Hu, **Jiawei Liu**, Zheng-Jun Zha
- ``IJCAI 2021`` [Multi-Scale Spatial-Temporal Integration Convolutional Tube for Human Action Recognition](https://www.ijcai.org/Proceedings/2020/0105.pdf) <br> Haoze Wu, **Jiawei Liu**, Xierong Zhu, Meng Wang, Zheng-Jun Zha
- ``CVPR 2021`` [Spatial-Temporal Correlation and Topology Learning for Person Re-Identification in Videos](https://openaccess.thecvf.com/content/CVPR2021/html/Liu_Spatial-Temporal_Correlation_and_Topology_Learning_for_Person_Re-Identification_in_Videos_CVPR_2021_paper.html) <br> **Jiawei Liu**, Zheng-Jun Zha, Wei Wu, Kecheng Zheng, Qibin Sun
</div>

<div class="academic-group publication-year-group" data-publication-year="2020" markdown="1">
- ``ACM MM 2020`` [Dual Context-Aware Refinement Network for Person Search](https://dl.acm.org/doi/10.1145/3394171.3413878) <br> **Jiawei Liu**, Zheng-Jun Zha, Richang Hong, Meng Wang, Yongdong Zhang
- `ACM MM 2020` [ASTA-Net: Adaptive Spatio-Temporal Attention Network for Person Re-Identification in Videos](https://dl.acm.org/doi/abs/10.1145/3394171.3413843) <br> Xierong Zhu, **Jiawei Liu**, Haoze Wu, Meng Wang, Zheng-Jun Zha
- ``ACM MM 2020`` [A Structured Graph Attention Network for Vehicle Re-Identification](https://dl.acm.org/doi/abs/10.1145/3394171.3413607) <br> Yangchun Zhu, Zheng-Jun Zha, Tianzhu Zhang, **Jiawei Liu**, Jiebo Luo
- ``ACM MM 2020`` [Hierarchical Gumbel Attention Network for Text-based Person Search](https://dl.acm.org/doi/10.1145/3394171.3413864) <br> Kecheng Zheng, Wu Liu, **Jiawei Liu**, Zheng-Jun Zha, Tao Mei
- ``ARXIV 2020`` [Temporal Attribute-Appearance Learning Network for Video-based Person Re-Identification](https://arxiv.org/pdf/2009.04181) <br> **Jiawei Liu**, Xierong Zhu, Zheng-Jun Zha
- ``IJCAI 2020`` [Co-Saliency Spatio-Temporal Interaction Network for Person Re-Identification in Videos](https://www.ijcai.org/proceedings/2020/0141.pdf) <br> **Jiawei Liu**, Zheng-Jun Zha, Xierong Zhu, Na Jiang
- ``IEEE TMM 2020`` [Adversarial Attribute-Text Embedding for Person Search With Natural Language Query](https://ieeexplore.ieee.org/abstract/document/8985326) <br> Zheng-Jun Zha, **Jiawei Liu**, Di Chen, Feng Wu
</div>

<div class="academic-group publication-year-group" data-publication-year="2019" markdown="1">
- ``ACM MM 2019`` [Deep Adversarial Graph Attention Convolution Network for Text-Based Person Search](https://dl.acm.org/doi/abs/10.1145/3343031.3350991) <br> **Jiawei Liu**, Zheng-Jun Zha, Richang Hong, Meng Wang, Yongdong Zhang
- ``IJCAI 2019`` [Mutually Reinforced Spatio-Temporal Convolutional Tube for Human Action Recognition](https://www.ijcai.org/proceedings/2019/136) <br> Haoze Wu, **Jiawei Liu**, Zheng-Jun Zha, Zhenzhong Chen, Xiaoyan Sun
- ``ACM TOMM 2019`` [Dense 3D-Convolutional Neural Network for Person Re-Identification in Videos](https://dl.acm.org/doi/abs/10.1145/3231741) <br> **Jiawei Liu**, Zheng-Jun Zha, Xuejin Chen, Zilei Wang, Yongdong Zhang
- ``MMM 2019`` [Adaptive Alignment Network for Person Re-identification](https://link.springer.com/chapter/10.1007/978-3-030-05716-9_2) <br> Xierong Zhu, **Jiawei Liu**, Hongtao Xie, Zheng-Jun Zha
- ``CVPR 2019`` [Adaptive Transfer Network for Cross-Domain Person Re-Identification](https://openaccess.thecvf.com/content_CVPR_2019/html/Liu_Adaptive_Transfer_Network_for_Cross-Domain_Person_Re-Identification_CVPR_2019_paper.html) <br> **Jiawei Liu**, Zheng-Jun Zha, Di Chen, Richang Hong, Meng Wang
- ``ACM TOMM 2019`` [Spatiotemporal-Textual Co-Attention Network for Video Question Answering](https://dl.acm.org/doi/abs/10.1145/3320061) <br> Zheng-Jun Zha, **Jiawei Liu**, Tianhao Yang, Yongdong Zhang
</div>

<div class="academic-group publication-year-group" data-publication-year="2018" markdown="1">
- ``ACM MM 2018`` [CA3Net: Contextual-Attentional Attribute-Appearance Network for Person Re-Identification](https://dl.acm.org/doi/abs/10.1145/3240508.3240585) <br> **Jiawei Liu**, Zheng-Jun Zha, Hongtao Xie, Zhiwei Xiong, Yongdong Zhang
- ``PCM 2018`` [Temporal-Contextual Attention Network for Video-Based Person Re-identification](https://link.springer.com/chapter/10.1007/978-3-030-00776-8_14) <br> Di Chen, Zheng-Jun Zha, **Jiawei Liu**, Hongtao Xie, Yongdong Zhang
</div>

<div class="academic-group publication-year-group" data-publication-year="2016" markdown="1">
- ``ACM MM 2016`` [Multi-Scale Triplet CNN for Person Re-Identification](https://dl.acm.org/doi/abs/10.1145/2964284.2967209) <br> **Jiawei Liu**, Zheng-Jun Zha, QI Tian, Dong Liu, Ting Yao, Qiang Ling, Tao Mei
</div>

<script>
(function () {
  'use strict';

  var section = document.querySelector('.section-publications');
  var controls = document.getElementById('publications-year-tabs');
  if (!section || !controls) return;

  // Each year is a real source-level group containing its original paper entries.
  var yearGroups = Array.prototype.slice.call(
    section.querySelectorAll('.publication-year-group')
  );
  if (!yearGroups.length) return;

  var counts = {};
  var totalCount = 0;
  yearGroups.forEach(function (group) {
    var year = group.getAttribute('data-publication-year');
    var count = group.querySelectorAll('li').length;
    counts[year] = count;
    totalCount += count;
  });

  function selectYear(year, selectedButton) {
    yearGroups.forEach(function (group) {
      var groupYear = group.getAttribute('data-publication-year');
      group.hidden = year !== 'ALL' && groupYear !== year;
    });

    // Add subtle year separators only when all publication years are visible.
    section.classList.toggle('show-all-years', year === 'ALL');

    Array.prototype.forEach.call(controls.querySelectorAll('button'), function (button) {
      var selected = button === selectedButton;
      button.classList.toggle('is-active', selected);
      button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    });
  }

  function addYearButton(label, count, filterYear) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'news-year-tab';
    button.setAttribute('aria-label', label === 'ALL'
      ? 'Show all ' + count + ' publications'
      : 'Show ' + count + ' publications from ' + label);

    var yearLabel = document.createElement('span');
    yearLabel.textContent = label;
    yearLabel.setAttribute('aria-hidden', 'true');

    var countLabel = document.createElement('small');
    countLabel.className = 'news-year-count';
    countLabel.textContent = count;
    countLabel.setAttribute('aria-hidden', 'true');

    button.appendChild(yearLabel);
    button.appendChild(countLabel);
    button.addEventListener('click', function () {
      selectYear(filterYear, button);
    });
    controls.appendChild(button);
    return button;
  }

  var firstButton = null;
  yearGroups.forEach(function (group, index) {
    var year = group.getAttribute('data-publication-year');
    var button = addYearButton(year, counts[year], year);
    if (index === 0) firstButton = button;
  });

  // ALL is always the final tab.
  var allButton = addYearButton('ALL', totalCount, 'ALL');

  // Default to the latest publication year (the groups are ordered newest first).
  if (firstButton) {
    selectYear(yearGroups[0].getAttribute('data-publication-year'), firstButton);
  } else {
    selectYear('ALL', allButton);
  }
})();
</script>

</div>

<span class='anchor' id='chinese-patents'></span>
<span class='anchor' id='-chinese-patents'></span>

<div class="academic-card section-patents" markdown="1">

<h1 id="-patents">Patents</h1>

<div class="academic-group dated-list" markdown="1">
- *2026.10* <span class="patent-title">一种类比先例引导的自适应科学推理方法及系统</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 展宏民; 张凡瑞</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202611591166.4</span></span>
- *2026.04* <span class="patent-title">一种基于强化学习框架的开放词汇人物交互检测方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 徐永超; 王浚沣</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202610429538.7</span></span>
- *2026.03* <span class="patent-title">基于检索与推理增强大语言模型的多模态事实核查方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 展宏民; 张凡瑞</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202610248544.2</span></span>
- *2025.11* <span class="patent-title">基于冲突感知检索和多级协同引导的多模态知识编辑方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 张强; 张凡瑞</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202511709848.6</span></span>
- *2025.10* <span class="patent-title">基于双重不确定性引导特征对齐的文本到图像行人检索方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 郑雨霏</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202511451428.2</span></span>
- *2025.03* <span class="patent-title">一种基于Mamba架构的人物交互检测方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 徐永超</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202510261091.2</span></span>
- *2024.10* <span class="patent-title">一种基于实体增强和立场检查的多模态事实核查方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 张凡瑞; 张强</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202410403673.5</span></span>
- *2024.10* <span class="patent-title">基于特征多样化和域自适应特征选择的鲁棒行人重识别方法</span><span class="patent-inventors"><strong>刘嘉威</strong>; 赵国治; 吴勇; 贺强; 胡冰玉</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202410070798.0</span></span>
- *2024.10* <span class="patent-title">一种基于跨模态语义对齐的文本行人重识别方法</span><span class="patent-inventors"><strong>刘嘉威</strong>; 赵国治; 吴勇; 贺强; 甘文君</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202410072896.8</span></span>
- *2024.10* <span class="patent-title">一种基于噪声辅助提示学习的图像伪造检测定位方法</span><span class="patent-inventors">查正军; 傅雪阳; 李东; 朱佳莹; <strong>刘嘉威</strong></span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202411253779.8</span></span>
- *2023.10* <span class="patent-title">基于边缘感知的区域消息传递控制的图像伪造定位方法</span><span class="patent-inventors">查正军; 傅雪阳; 李东; 朱佳莹; <strong>刘嘉威</strong></span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202310346607.4</span></span>
- *2023.11* <span class="patent-title">一种基于多层次语义增强的多模态假新闻检测方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 张强; 张凡瑞</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202311298800.1</span></span>
- *2022.10* <span class="patent-title">一种基于特征对齐的退化环境下的行人重识别方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 王堃宇</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202210792619.5</span></span>
- *2022.10* <span class="patent-title">基于时序补偿引导的强化学习图像-视频行人重识别方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 吴蔚</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202210362412.4</span></span>
- *2022.10* <span class="patent-title">基于高斯过程的去偏批量归一化的鲁棒行人重识别方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 黄志鹏</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202210193826.9</span></span>
- *2022.10* <span class="patent-title">基于模态自适应混合和不变性卷积分解的行人重识别方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong>; 黄志鹏</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202210155715.9</span></span>
- *2020.10* <span class="patent-title">检索目标的方法和装置</span><span class="patent-inventors">刘武; <strong>刘嘉威</strong>; 梅涛; 郑可成</span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN202010215923.4</span></span>
- *2019.10* <span class="patent-title">行人再识别数据生成方法</span><span class="patent-inventors">查正军; <strong>刘嘉威</strong></span><span class="patent-meta"><span class="patent-kind">发明专利</span><span class="patent-number">专利号：CN201910466234.8</span></span>
</div>

</div>

<span class='anchor' id='honors-and-awards'></span>

<div class="academic-card section-honors-and-awards" markdown="1">

<h1 id="-honors-and-awards">Honors &amp; Awards</h1>

<div class="academic-group dated-list" markdown="1">
- *2026.06* CVPR2026 Workshop: MultiModal Deception Detection Challenge ([1st Place Award](https://www.codabench.org/competitions/12678/#/results-tab)) 
- *2025.10* First-Class Award of Anhui Provincial Natural Science Award [(3/3)](https://kjt.ah.gov.cn/kjzx/tzgg/123091461.html)
- *2025.10* PRCV2025 Workshop: Omni Multi-modal Person Re-identification Challenge (Excellence Award)
- *2024.07* ACM MM2024 Workshop: Micro-Action Analysis Grand Challenge ([3rd Place Award](https://sites.google.com/view/micro-action/challenge/winners))
- *2023.03* AAAI2023 Workshop: Defactify 2: Multimodal Fake News Detection ([4th Place Award](https://aiisc.ai/defactify2/))
- *2022.01* Mozi Distinguished Youth Special Allowance of USTC
- *2020.01* Special Research Assistantship of CAS
- *2019.06* CAS Presidential Scholarship
- *2019.06* Outstanding Graduates Scholarship, USTC
- *2018.09* Individual Scholarship, USTC
- *2016.09* Individual Scholarship, USTC
</div>

</div>

<span class='anchor' id='experiences'></span>
<span class='anchor' id='-experiences'></span>

<div class="academic-card section-experience" markdown="1">

<h1 id="-experience">Experience</h1>

<div class="academic-group">
<h3>Professional Experience</h3>

<ol class="experience-timeline">
  <li>
    <span class="experience-date">2026.05 – Present</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--ustc" aria-hidden="true"><img src="{{ '/images/experience-ustc.jpg' | relative_url }}" alt=""></span><span>University of Science and Technology of China</span></strong>
      <span class="experience-role">Associate Professor</span>
      <span class="experience-detail">Department of Automation</span>
      <span class="experience-detail">Collaborating with <a href="https://auto.ustc.edu.cn/2021/0510/c25976a484878/page.htm">Prof. Zheng-Jun Zha</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2025.09 – 2026.08</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--nus" aria-hidden="true"><img src="{{ '/images/nus.png' | relative_url }}" alt=""></span><span>National University of Singapore</span></strong>
      <span class="experience-role">Visiting Scholar</span>
      <span class="experience-detail">School of Computing · Department of Computer Science</span>
      <span class="experience-detail">Host: <a href="https://www.comp.nus.edu.sg/cs/people/yansc/">Prof. Shuicheng Yan</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2021.12 – 2026.04</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--ustc" aria-hidden="true"><img src="{{ '/images/experience-ustc.jpg' | relative_url }}" alt=""></span><span>University of Science and Technology of China</span></strong>
      <span class="experience-role">Associate Research Fellow</span>
      <span class="experience-detail">Department of Automation</span>
      <span class="experience-detail">Collaborating with <a href="https://auto.ustc.edu.cn/2021/0510/c25976a484878/page.htm">Prof. Zheng-Jun Zha</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2019.10 – 2021.11</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--ustc" aria-hidden="true"><img src="{{ '/images/experience-ustc.jpg' | relative_url }}" alt=""></span><span>University of Science and Technology of China</span></strong>
      <span class="experience-role">Postdoctoral Research Fellow</span>
      <span class="experience-detail">Department of Automation</span>
      <span class="experience-detail">Collaborating with <a href="https://auto.ustc.edu.cn/2021/0510/c25976a484878/page.htm">Prof. Zheng-Jun Zha</a> and <a href="https://faculty.ustc.edu.cn/zhangyongdong/en/index.htm">Prof. Yongdong Zhang</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2019.08 – 2019.10</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--jd" aria-hidden="true"><img src="{{ '/images/experience-jd.png' | relative_url }}" alt=""></span><span>JD AI Research Institute</span></strong>
      <span class="experience-role">Researcher</span>
      <span class="experience-detail">Working with <a href="https://taomei.me/">Prof. Tao Mei</a> and <a href="https://faculty.ustc.edu.cn/liuwu/zh_CN/index.htm">Prof. Wu Liu</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2016.10 – 2017.01</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--microsoft" aria-hidden="true"><img src="{{ '/images/experience-microsoft.svg' | relative_url }}" alt=""></span><span>Microsoft Research Asia</span></strong>
      <span class="experience-role">Research Intern</span>
      <span class="experience-detail">Supervisor: <a href="https://taomei.me/">Prof. Tao Mei</a></span>
    </div>
  </li>
</ol>

<h3>Education</h3>

<ol class="experience-timeline">
  <li>
    <span class="experience-date">2014.09 – 2019.06</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--ustc" aria-hidden="true"><img src="{{ '/images/experience-ustc.jpg' | relative_url }}" alt=""></span><span>University of Science and Technology of China</span></strong>
      <span class="experience-role">Ph.D.</span>
      <span class="experience-detail">Control Science and Engineering · Department of Automation</span>
      <span class="experience-detail">Advisor: <a href="https://auto.ustc.edu.cn/2021/0510/c25976a484878/page.htm">Prof. Zheng-Jun Zha</a></span>
    </div>
  </li>
  <li>
    <span class="experience-date">2009.08 – 2013.07</span>
    <div class="experience-entry">
      <strong class="experience-institution"><span class="experience-logo experience-logo--hfut" aria-hidden="true"><img src="{{ '/images/experience-hfut.svg' | relative_url }}" alt=""></span><span>Hefei University of Technology</span></strong>
      <span class="experience-role">B.S.</span>
      <span class="experience-detail">Automation · Department of Automation</span>
      <span class="experience-detail">Advisor: Prof. Chenghui Zhu</span>
    </div>
  </li>
</ol>
</div>

</div>

<span class='anchor' id='fundings'></span>

<div class="academic-card section-fundings" markdown="1">

<h1 id="-fundings">Funding</h1>

<div class="academic-group dated-list" markdown="1">
- *2025.01 – 2028.12* <span class="funding-main"><span class="funding-title">National Natural Science Foundation of China, General Program</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">基金委面上基金项目, 主持</span>
- *2025.09 – 2026.08* <span class="funding-main"><span class="funding-title">CCF-1688 Yuanbao Cooperation Fund</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">CCF-1688源宝合作基金项目，主持</span>
- *2025.01 – 2026.12* <span class="funding-main"><span class="funding-title">USTC Research Funds of the Double First-Class Initiative</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">校青年创新重点基金项目, 主持</span>
- *2022.01 – 2024.12* <span class="funding-main"><span class="funding-title">National Natural Science Foundation of China, Youth Program</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">基金委青年基金项目, 主持</span>
- *2023.06 – 2024.12* <span class="funding-main"><span class="funding-title">China Merchants Bank-USTC Laboratory Collaborative Project</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">招商银行-中国科大实验室合作项目, 主持</span>
- *2021.01 – 2022.12* <span class="funding-main"><span class="funding-title">USTC Research Funds of the Double First-Class Initiative</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">校青年创新基金项目, 主持</span>
- *2021.01 – 2022.12* <span class="funding-main"><span class="funding-title">China Postdoctoral Science Foundation</span><span class="funding-role funding-role--lead">PI</span></span><span class="funding-local">中国博士后面上基金项目, 主持</span>
- *2024.07 – 2029.06* <span class="funding-main"><span class="funding-title">Chinese Academy of Sciences Stable Support Basic Research Youth Team Program</span><span class="funding-role funding-role--lead">Subproject PI</span></span><span class="funding-local">中国科学院稳定支持基础研究领域青年团队计划, 课题主持</span>
- *2024.04 – 2030.12* <span class="funding-main"><span class="funding-title">Strategic Priority Project of the Chinese Academy of Sciences on Securing the High Ground in Science and Technology</span><span class="funding-role funding-role--participant">Key Participant</span></span><span class="funding-local">中国科学院抢占科技制高点专项课题，参与</span>
- *2025.01 – 2026.12* <span class="funding-main"><span class="funding-title">USTC Research Funds of the Double First-Class Initiative</span><span class="funding-role funding-role--participant">Key Participant</span></span><span class="funding-local">校融合专项基金项目, 参与</span>
- *2020.11 – 2023.10* <span class="funding-main"><span class="funding-title">National Key R&D Program of China</span><span class="funding-role funding-role--participant">Key Participant</span></span><span class="funding-local">科技创新2030-"新一代人工智能"重大项目, 参与</span>
- *2020.01 – 2023.12* <span class="funding-main"><span class="funding-title">Joint Funds of the National Natural Science Foundation of China</span><span class="funding-role funding-role--participant">Key Participant</span></span><span class="funding-local">基金委联合重点基金项目, 参与</span>
- *2017.01 – 2021.12* <span class="funding-main"><span class="funding-title">National Key R&D Program of China</span><span class="funding-role funding-role--participant">Key Participant</span></span><span class="funding-local">国家重点研发计划课题, 参与</span>
</div>

</div>

<div class="academic-card section-teaching" markdown="1">

<h1 id="-teaching">Teaching</h1>

<div class="teaching-course">
  <h3>Graduate Courses</h3>
  <div class="teaching-row">
    <span class="teaching-course-name">Computer Vision <span>(计算机视觉)</span></span>
    <span class="teaching-meta">60 teaching hours · Fall 2022–2026</span>
  </div>
</div>

<div class="teaching-course">
  <h3>Undergraduate Courses</h3>
  <div class="teaching-row">
    <span class="teaching-course-name">Python and Deep Learning Fundamentals <span>(Python与深度学习基础)</span></span>
    <span class="teaching-meta">40 teaching hours · Spring 2025</span>
  </div>
</div>

</div>

<span class='anchor' id='professional-activities'></span>
<span class='anchor' id='-professional-activities'></span>

<div class="academic-card section-academic-service" markdown="1">

<h1 id="-academic-service">Academic Service</h1>

<div class="academic-group" markdown="1">
<h3>Expert Service</h3>

- Expert in the National Graduate Education Evaluation and Monitoring Expert Database
- Expert in the National Undergraduate Thesis (Design) Random Inspection and Evaluation Expert Database
- [Member of CSIG Technical Committee on Multimedia](http://mm.csig.org.cn/?page_id=263 )
- Member of CSIG Technical Committee on Digital Media Forensics and Security
- Member of CCF Technical Committee on Multimedia Technology
</div>

<div class="academic-group" markdown="1">
<h3>Young Editorial Board Member</h3>

- Journal of Intelligent Computing and Networking

<h3 class="journal-reviewer-heading">Journal Reviewer</h3>

- IEEE Transactions on Pattern Analysis and Machine Intelligence
- International Journal of Computer Vision
- IEEE Transactions on Multimedia
- IEEE Transactions on Cybernetics
- IEEE Transactions on Image Processing
- IEEE Transactions on Emerging Topics in Computational Intelligence
- IEEE Transactions on Neural Networks and Learning Systems
- IEEE Transactions on Circuits and Systems for Video Technology
- IEEE Transactions on Dependable and Secure Computing
- IEEE Transactions on Artificial Intelligence
- IEEE Transactions on Industrial Informatics
- IEEE Transactions on Computational Social Systems
- IEEE Transactions on Automation Science and Engineering
- IEEE Transactions on Consumer Electronics
- ACM Transactions on Data Science
- ACM Transactions on Multimedia Computing Communications and Applications
- Neurocomputing
- Neural Networks
- Image and Vision Computing
- Computer Vision and Image Understanding
- IEEE Internet of Things Journal
- IEEE Signal Processing Letters
- Pattern Recognition Letters
- IEEE Sensors Letters
- Journal of Computer Science and Technology

<h3>Conference Area Chair or Senior Program Committee</h3>

- AAAI Conference on Artificial Intelligence
- Chinese Control Conference

<h3>Conference Reviewer</h3>

- NeurIPS, CVPR, ICCV, ECCV, ICML, ICLR, ACM MM, IJCAI, AAAI, ICME, PRCV, ACCV
</div>

</div>
